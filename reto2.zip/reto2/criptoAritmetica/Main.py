import GeneticSol

GeneticSol.GeneticSol(["SOLAR", "POWER"], "EXCEL")